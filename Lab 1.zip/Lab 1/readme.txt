initScene() function:

The compile() function is called to compile and link the shader program. Depth testing is enabled first so that depth information is rendered correctly.
A SkyBox object is created and the skybox's texture is loaded.
The positions of different light sources are set: spotLightPosition, pointLightPositions and pointLightPosition2.
Various models and textures in the scene are loaded, such as ground, models, trees, fences, etc.
compile() function:

Two shader programs are compiled and linked, one for rendering objects in the scene (basic_uniform.vert and basic_uniform.frag) and one for the skybox (skybox.vert and skybox.frag).
If compilation or linking fails, an error message will be output and the program will exit.
update(float t) function:

Update some parameters based on time, mainly used to control the rotation of objects and the movement of light sources.
rotSpeed defines the speed of rotation, and deltaTime is used to calculate the time interval.
render() function:

Clear the color buffer and depth buffer and set the clear color to dark gray.
Use the prog program object for rendering settings. Set the view matrix, projection matrix, etc.
Set lighting properties, including directional, point, and spot lights.
Bind textures and set material properties.
Render objects in the scene, including models, planes, and fences, each with its own position, rotation, and scale.
Finally, the skybox is rendered using the progSky procedural object, clearing the translation portion of the view matrix to ensure that the skybox is always centered on the camera.
Use glDepthFunc(GL_LESS) to restore the depth test function to its default value.
Together, these operations implement a complete OpenGL scene rendering process, including scene initialization, updating and rendering.



The fragment shader implements the following functions:

In the shader program object and setting some uniform variable values in the shader, Such as view position (viewPos), material gloss (shininess), Gaussian blur standard deviation (sigma), parallel light (dirLight), point light (pointLight) and spotLight (spotLight) properties.

Sets the view and projection matrix for perspective projection transformation and camera view transformation. These matrices are used to transform objects in the scene from world space to crop space for subsequent perspective projection and crop.

Bind textures (diffuseMap, alphaTexture) to the texture unit and set the corresponding texture sampler in the shader.

Three types of lighting effects are calculated and blended: directional light (dirLight), pointLight (pointLight), and spotLight (spotLight). These light sources calculate the lighting effect based on the normal and the direction of view of the object's surface, and blend them into the final color.

A mixing function, mix(), is used to mix the object's base color with an additional color. This extra color is obtained by sampling the alpha texture of the material.

Gaussian blur effect is applied. For each pixel, it calculates a weighted average of the pixels in a certain range around it to blur the image. The blur effect is calculated using a Gaussian function to calculate the weight of each pixel, and then the weighted average is applied to the image.
User input implements the following functions:

The window closes:
Check that the Escape key (GLFW_KEY_ESCAPE) is pressed.
If the Escape key is pressed, close the window by setting the window close flag to true (glfwSetWindowShouldClose(window, true))

Camera movement:
Check whether keys W, S, A, and D (GLFW_KEY_W, GLFW_KEY_S, GLFW_KEY_A, GLFW_KEY_D) are pressed.
If W is pressed, move the camera FORWARD (camera.processkeyboard (FORWARD, deltaTime)).
If the S key is pressed, move the camera backwards (camera.processkeyboard (BACKWARD, deltaTime)).
If the A key is pressed, move the camera to the LEFT (camera.processkeyboard (LEFT, deltaTime)).
If the D key is pressed, move the camera to the RIGHT (camera.processkeyboard (RIGHT, deltaTime)).


Animation:
The animation is located in the update(float t) function, which is used to update some parameters in the scene based on time t, mainly including:

angle: Indicates the rotation angle of the object. The rotation of the object is achieved by increasing the rotation speed rotSpeed by an increment every frame.
spotLightPosition: The position of the spotlight. Here the spotlight's position on the x-z plane is calculated using the cos(t) and sin(t) functions to produce a periodic moving effect, multiplied by 5 to place it further away from the origin.
pointLightPositions: The position of point light source 1. Similar to a spotlight, the position of a point light in the x-z plane is calculated using the cos(t) and sin(t) functions and multiplied by 5 to place it away from the origin.
pointLightPosition2: The position of point light source 2. Similar to Point Light 1, but the position is calculated differently. A periodic motion effect different from Point Light 1 is obtained through the sin(t) function, and multiplied by 2.5 to ensure that its range of motion on the x-z plane is smaller.
These update operations enable the light sources and objects in the scene to dynamically change over time, increasing the dynamics and visual effects of the scene.