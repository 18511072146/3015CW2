#ifndef SCENEBASIC_UNIFORM_H
#define SCENEBASIC_UNIFORM_H

#include "helper/scene.h"
#include "plane.h"
#include "camera.h"
#include "objmesh.h"
#include "texture.h"
#include "skybox.h"

#include <glad/glad.h>
#include "helper/glslprogram.h"

class SceneBasic_Uniform : public Scene
{
private:
    GLuint vaoHandle;
    GLSLProgram prog;
    GLSLProgram progTerrain;
    GLSLProgram progSky;
    GLSLProgram progNoise;

    float deltaTime = 0.0f;
    float lastFrame = 0.0f;
    glm::vec3 spotLightPosition;
    glm::vec3 pointLightPositions;
    glm::vec3 pointLightPosition2;
    float angle;
    Plane* plane;
    
    SkyBox* skybox;
    GLuint skyboxTexture;
    Camera *camera;
    GLuint alphaTexture;
    GLuint alphaLeafTexture;
    GLuint spotTexture;
    GLuint floorTexture;
    std::unique_ptr<ObjMesh> spot;

    GLuint backgoundTexture;
    GLuint treeTexture;
    GLuint treeLeafTexture;
    GLuint treeBarkTexture;

    std::unique_ptr<ObjMesh> background;
    std::unique_ptr<ObjMesh> tree1;
    std::unique_ptr<ObjMesh> treeleaf;
    std::unique_ptr<ObjMesh> ground;
    void compile();
    void genNoiseText(int w,int h);

public:
    SceneBasic_Uniform();

    void initScene();
    void update( float t );
    void render();
    void resize(int, int);
    void processMouseMovement(float , float );
    void processKeyboard(int);
};

#endif // SCENEBASIC_UNIFORM_H
